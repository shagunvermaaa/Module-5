$(function () {
  $("#navbarToggle").blur(function (event) {
    var screenWidth = window.innerWidth;
    if (screenWidth < 768) {
      $("#collapsable-nav").collapse('hide');
    }
  });
});

(function (global) {
  var dc = {};

  var homeHtml = "snippets/home-snippet.html";
  var allCategoriesUrl =
    "https://coursera-jhu-default-rtdb.firebaseio.com/categories.json";
  var menuItemsUrl =
    "https://coursera-jhu-default-rtdb.firebaseio.com/menu_items/{{short_name}}.json";
  var menuItemsTitleHtml = "snippets/menu-items-title.html";
  var menuItemHtml = "snippets/menu-item.html";

  var insertHtml = function (selector, html) {
    document.querySelector(selector).innerHTML = html;
  };

  var showLoading = function (selector) {
    var html = "<div class='text-center'>";
    html += "<img src='images/ajax-loader.gif'></div>";
    insertHtml(selector, html);
  };

  var insertProperty = function (string, propName, propValue) {
    var propToReplace = "{{" + propName + "}}";
    return string.replace(new RegExp(propToReplace, "g"), propValue);
  };

  document.addEventListener("DOMContentLoaded", function () {
    showLoading("#main-content");
    $ajaxUtils.sendGetRequest(allCategoriesUrl, function (categories) {
      var randomCategory = chooseRandomCategory(categories);
      $ajaxUtils.sendGetRequest(homeHtml, function (homeHtmlContent) {
        var updatedHtml = insertProperty(
          homeHtmlContent,
          "randomCategoryShortName",
          randomCategory.short_name
        );
        insertHtml("#main-content", updatedHtml);
      }, false);
    }, true);
  });

  function chooseRandomCategory(categories) {
    var randomIndex = Math.floor(Math.random() * categories.length);
    return categories[randomIndex];
  }

  dc.loadMenuItems = function (categoryShortName) {
    showLoading("#main-content");
    var url = insertProperty(menuItemsUrl, "short_name", categoryShortName);
    $ajaxUtils.sendGetRequest(url, buildAndShowMenuItemsHTML);
  };

  function buildAndShowMenuItemsHTML(categoryMenuItems) {
    $ajaxUtils.sendGetRequest(menuItemsTitleHtml, function (titleHtml) {
      $ajaxUtils.sendGetRequest(menuItemHtml, function (itemHtml) {
        var finalHtml = buildMenuItemsViewHtml(
          categoryMenuItems,
          titleHtml,
          itemHtml
        );
        insertHtml("#main-content", finalHtml);
      }, false);
    }, false);
  }

  function buildMenuItemsViewHtml(categoryMenuItems, titleHtml, itemHtml) {
    titleHtml = insertProperty(titleHtml, "name", categoryMenuItems.category.name);
    titleHtml = insertProperty(
      titleHtml,
      "special_instructions",
      categoryMenuItems.category.special_instructions
    );

    var finalHtml = titleHtml + "<section class='row'>";
    var menuItems = categoryMenuItems.menu_items;

    for (var i = 0; i < menuItems.length; i++) {
      var html = itemHtml;
      var item = menuItems[i];

      html = insertProperty(html, "short_name", item.short_name);
      html = insertProperty(html, "name", item.name);
      html = insertProperty(html, "description", item.description);
      html = insertProperty(
        html,
        "price_small",
        item.price_small ? "$" + item.price_small.toFixed(2) : ""
      );
      html = insertProperty(
        html,
        "price_large",
        item.price_large ? "$" + item.price_large.toFixed(2) : ""
      );
      html = insertProperty(
        html,
        "small_portion_name",
        item.small_portion_name || ""
      );
      html = insertProperty(
        html,
        "large_portion_name",
        item.large_portion_name || ""
      );

      finalHtml += html;
    }

    finalHtml += "</section>";
    return finalHtml;
  }

  global.$dc = dc;
})(window);
