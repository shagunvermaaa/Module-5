var helloSpeaker = {};

helloSpeaker.speak = function (name) {
  console.log("Hello " + name);
};
