var byeSpeaker = {};

byeSpeaker.speak = function (name) {
  console.log("Goodbye " + name);
};
